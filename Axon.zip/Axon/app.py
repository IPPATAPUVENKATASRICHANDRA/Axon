import os
from flask import Flask, render_template, request, redirect, url_for, session, send_file
from flask_pymongo import PyMongo
from werkzeug.security import generate_password_hash, check_password_hash
from bson.objectid import ObjectId
from gridfs import GridFS
from moviepy.editor import VideoFileClip
import speech_recognition as sr
from pydub import AudioSegment
from datetime import timedelta
from deep_translator import GoogleTranslator
import re
from sumy.parsers.plaintext import PlaintextParser
from sumy.nlp.tokenizers import Tokenizer
from sumy.summarizers.lsa import LsaSummarizer
from langchain import HuggingFaceHub, PromptTemplate, LLMChain
from transformers import T5Tokenizer, T5ForConditionalGeneration
from flask import send_file
import os
import zipfile
import io
import zipfile
from io import BytesIO


app = Flask(__name__)
app.config["MONGO_URI"] = "mongodb://localhost:27017/Axon"
app.secret_key = "supersecretkey"
mongo = PyMongo(app)
fs = GridFS(mongo.db)

UPLOAD_FOLDER = "uploads"
TRANSCRIPT_FOLDER = "transcripts"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(TRANSCRIPT_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["TRANSCRIPT_FOLDER"] = TRANSCRIPT_FOLDER


# Load pre-trained T5 model and tokenizer
model_name = "t5-small"
tokenizer = T5Tokenizer.from_pretrained(model_name)
model = T5ForConditionalGeneration.from_pretrained(model_name)

# --------------------------------------------------------------------------------------------------------


# the video to audio conversion function
def video_to_audio(video_path, audio_path):
    video = VideoFileClip(video_path)
    video.audio.write_audiofile(audio_path)
    video.close()


# this function formats the timestamp in milliseconds to the format HH:MM:SS.mmm
def format_timestamp(milliseconds):
    td = timedelta(milliseconds=milliseconds)
    total_seconds = int(td.total_seconds())
    hours, remainder = divmod(total_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    milliseconds = td.microseconds // 1000
    return f"{hours:02}:{minutes:02}:{seconds:02}.{milliseconds:03}"


# this function transcribes the audio file in chunks of 30 seconds


def transcribe_audio(audio_path, output_txt_path):
    recognizer = sr.Recognizer()
    audio = AudioSegment.from_file(audio_path)

    chunk_length_ms = 10000  # 30 seconds
    chunks = [
        audio[i : i + chunk_length_ms] for i in range(0, len(audio), chunk_length_ms)
    ]

    with open(output_txt_path, "w") as txt_file:
        for i, chunk in enumerate(chunks):
            chunk.export(f"chunk{i}.wav", format="wav")
            with sr.AudioFile(f"chunk{i}.wav") as source:
                audio_listened = recognizer.record(source)
                try:
                    transcript = recognizer.recognize_google(audio_listened)
                    start_time = format_timestamp(i * chunk_length_ms)
                    end_time = format_timestamp((i + 1) * chunk_length_ms)
                    txt_file.write(f"{start_time} --> {end_time}\n{transcript}\n\n")
                except sr.UnknownValueError:
                    txt_file.write(f"{start_time} --> {end_time}\n[unintelligible]\n\n")
                except sr.RequestError as e:
                    txt_file.write(f"{start_time} --> {end_time}\n[error: {e}]\n\n")
            os.remove(f"chunk{i}.wav")


# --------------------------------------------------------------------------------------------------------


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/process_video")
def process_video():
    return render_template("process_video.html")


# the login function where the user can login by providing their email and password
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]
        user = mongo.db.users.find_one({"email": email})
        if user and check_password_hash(user["password"], password):
            session["email"] = email
            session["username"] = user["username"]
            return redirect(url_for("dashboard"))
        return "Invalid email or password"
    return render_template("login.html")


# the register function where the user can register by providing their username, email, and password
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        email = request.form["email"]
        password = request.form["password"]
        existing_user = mongo.db.users.find_one({"email": email})
        if existing_user is None:
            hashpass = generate_password_hash(password)
            mongo.db.users.insert_one(
                {"username": username, "email": email, "password": hashpass}
            )
            session["email"] = email
            session["username"] = username
            return redirect(url_for("dashboard"))
        return "User already exists!"
    return render_template("register.html")


# the dashboard function where the user can view their dashboard if they are logged in
@app.route("/dashboard")
def dashboard():
    if "email" in session:
        return render_template(
            "user.html", email=session["email"], username=session["username"]
        )
    return redirect(url_for("login"))


# the upload function where the user can upload a video file
@app.route("/upload", methods=["GET", "POST"])
def upload():
    if "email" not in session:
        return redirect(url_for("login"))
    if request.method == "POST":
        if "video" in request.files:
            video = request.files["video"]
            video_id = fs.put(
                video, filename=video.filename, content_type=video.content_type
            )
            return redirect(url_for("transcribe", video_id=str(video_id)))
        return "No video uploaded"
    return render_template("upload.html")


# the transcribe function where the user can transcribe the uploaded video file
@app.route("/transcribe/<video_id>", methods=["GET", "POST"])
def transcribe(video_id):
    if "email" not in session:
        return redirect(url_for("login"))

    video_file = fs.get(ObjectId(video_id))
    video_path = os.path.join(app.config["UPLOAD_FOLDER"], video_file.filename)

    with open(video_path, "wb") as f:
        f.write(video_file.read())

    audio_path = "temp_audio.wav"
    output_txt_path = os.path.join(
        app.config["TRANSCRIPT_FOLDER"], f"transcription_{video_id}.txt"
    )

    video_to_audio(video_path, audio_path)

    # Release the video file before attempting to delete it
    try:
        os.remove(video_path)
    except PermissionError as e:
        print(f"Error removing video file: {e}")

    transcribe_audio(audio_path, output_txt_path)

    os.remove(audio_path)

    return render_template(
        "transcribe.html",
        transcript_path=url_for("download_transcript", video_id=video_id),
    )


# the download_transcript function where the user can download the transcribed text file
@app.route("/download_transcript/<video_id>")
def download_transcript(video_id):
    if "email" not in session:
        return redirect(url_for("login"))

    transcript_path = os.path.join(
        app.config["TRANSCRIPT_FOLDER"], f"transcription_{video_id}.txt"
    )
    return send_file(
        transcript_path, as_attachment=True, download_name="transcription.txt"
    )


# the logout function where the user can logout
@app.route("/logout")
def logout():
    session.pop("email", None)
    session.pop("username", None)
    return redirect(url_for("index"))


from deep_translator import GoogleTranslator
import re

MAX_CHUNK_SIZE = 4500  # Maximum size for each chunk


@app.route("/translate", methods=["GET", "POST"])
def translate():
    if "email" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        if "transcript" not in request.files:
            return "No file uploaded"

        file = request.files["transcript"]
        target_language = request.form["target_language"]

        if file.filename == "":
            return "No file selected"

        if file:
            filename = file.filename
            file_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
            file.save(file_path)

            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()

            # Split content into segments (timestamp + text)
            segments = re.split(
                r"(\d{2}:\d{2}:\d{2}\.\d{3} --> \d{2}:\d{2}:\d{2}\.\d{3})", content
            )

            # Translate text segments
            translator = GoogleTranslator(source="auto", target=target_language)
            translated_segments = []

            for i, segment in enumerate(segments):
                if i % 2 == 0:  # Even indices are text content
                    # Split text into chunks if it's too long
                    chunks = [
                        segment[j : j + MAX_CHUNK_SIZE]
                        for j in range(0, len(segment), MAX_CHUNK_SIZE)
                    ]
                    translated_chunks = []
                    for chunk in chunks:
                        if chunk.strip():  # Translate only non-empty chunks
                            translated_chunks.append(translator.translate(chunk))
                    translated_segments.append(" ".join(translated_chunks))
                else:  # Odd indices are timestamps
                    translated_segments.append(segment)

            # Join translated segments
            translated_content = "\n".join(translated_segments)

            # Create the translated file
            translated_filename = f"translated_{filename}"
            translated_file_path = os.path.join(
                app.config["UPLOAD_FOLDER"], translated_filename
            )

            with open(translated_file_path, "w", encoding="utf-8") as f:
                f.write(translated_content)

            # Clean up the original file
            os.remove(file_path)

            return send_file(
                translated_file_path,
                as_attachment=True,
                download_name=translated_filename,
            )

    return render_template("translate.html")


# --------------------------------------------------------------------------------------------------------
@app.route("/summarize", methods=["GET", "POST"])
def summarize():
    if "email" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        if "transcript" not in request.files:
            return render_template("summarize.html", error="No file uploaded")

        file = request.files["transcript"]

        if file.filename == "":
            return render_template("summarize.html", error="No file selected")

        if file:
            filename = file.filename
            file_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
            file.save(file_path)

            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()

            # Split content into segments (timestamp + text)
            segments = re.split(
                r"(\d{2}:\d{2}:\d{2}\.\d{3} --> \d{2}:\d{2}:\d{2}\.\d{3})", content
            )

            # Extract only text content (odd indices in segments)
            text_content = " ".join(segments[2::2])

            # Tokenize and summarize the input text using T5
            inputs = tokenizer.encode(
                "summarize: " + text_content,
                return_tensors="pt",
                max_length=1024,
                truncation=True,
            )
            summary_ids = model.generate(
                inputs,
                max_length=900,
                min_length=50,
                length_penalty=2.0,
                num_beams=4,
                early_stopping=True,
            )

            # Decode and output the summary
            summary = tokenizer.decode(summary_ids[0], skip_special_tokens=True)

            # Clean up the original file
            os.remove(file_path)

            # Save the summary to a file
            summary_path = os.path.join(app.config["UPLOAD_FOLDER"], "summary.txt")
            with open(summary_path, "w", encoding="utf-8") as f:
                f.write(summary)

            return render_template("summarize.html", summary=summary)

    return render_template("summarize.html")


# --------------------------------------------------------------------------------------------------------

@app.route('/about')
def about():
    return render_template('about.html')

def multi_llm_user(data):
    try:
        os.environ["HUGGINGFACEHUB_API_TOKEN"] = "HUGGING_FACE_KEY"
        model_id = "microsoft/Phi-3-mini-4k-instruct"

        falcon_llm = HuggingFaceHub(
            repo_id=model_id,
            model_kwargs={"temperature": 0.7, "max_new_tokens": 50},
        )

        template = """
            You are an AI assistant that generates a captivating heading from the given content.
            Your goal is to create a heading that is engaging, intriguing, and makes people want to learn more about the topic.
            The heading should be in question form and must be 10 to 11 words long.
            
            content:
            {data}

            Generate a captivating heading (10-11 words) in question form:
            
            response:
        """

        prompt = PromptTemplate(template=template, input_variables=["data"])
        falcon_chain = LLMChain(llm=falcon_llm, prompt=prompt, verbose=True)
        output = falcon_chain.run(data)

        # showing only the generated title
        output = output.split("response:")[1]

        return output.strip()

    except Exception as e:
        return f"Error: {str(e)}"


@app.route("/title_generation", methods=["GET", "POST"])
def title_generation():
    if "email" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        summary_path = os.path.join(app.config["UPLOAD_FOLDER"], "summary.txt")

        if not os.path.exists(summary_path):
            return render_template(
                "title_generation.html",
                error="Summary file not found. Please generate a summary first.",
            )

        try:
            with open(summary_path, "r", encoding="utf-8") as f:
                summary_content = f.read()

            if not summary_content.strip():
                return render_template(
                    "title_generation.html", error="Summary file is empty."
                )

            print("Summary content:", summary_content)  # For debugging
            title = multi_llm_user(summary_content)

            # Save the title to a file
            title_path = os.path.join(app.config["UPLOAD_FOLDER"], "title.txt")
            with open(title_path, "w", encoding="utf-8") as f:
                f.write(title)

            return render_template("title_generation.html", title=title)

        except Exception as e:
            return render_template(
                "title_generation.html", error=f"An error occurred: {str(e)}"
            )

    return render_template("title_generation.html")


# --------------------------------------------------------------------------------------------------------


@app.route("/download_summary")
def download_summary():
    summary_path = os.path.join(app.config["UPLOAD_FOLDER"], "summary.txt")
    return send_file(summary_path, as_attachment=True, download_name="summary.txt")


# --------------------------------------------------------------------------------------------------------


@app.route("/download_all")
def download_all():
    if "email" not in session:
        return redirect(url_for("login"))

    # Create a BytesIO object to store the zip file
    memory_file = BytesIO()

    # Create a ZipFile object
    with zipfile.ZipFile(memory_file, "w") as zf:
        # Add transcription file
        transcript_path = os.path.join(
            app.config["TRANSCRIPT_FOLDER"], "transcription.txt"
        )
        if os.path.exists(transcript_path):
            zf.write(transcript_path, "transcription.txt")

        # Add summary file
        summary_path = os.path.join(app.config["UPLOAD_FOLDER"], "summary.txt")
        if os.path.exists(summary_path):
            zf.write(summary_path, "summary.txt")

        # Add title file
        title_path = os.path.join(app.config["UPLOAD_FOLDER"], "title.txt")
        if os.path.exists(title_path):
            zf.write(title_path, "title.txt")

    # Move to the beginning of the BytesIO buffer
    memory_file.seek(0)

    return send_file(
        memory_file,
        mimetype="application/zip",
        as_attachment=True,
        download_name="all_results.zip",
    )


if __name__ == "__main__":
    app.run(debug=True)
